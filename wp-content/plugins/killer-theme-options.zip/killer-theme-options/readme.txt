=== Killer Theme Options ===
Contributors: punitpatel
Tags: custom theme option, theme options, logo upload, dynamic social links, dynamic tracking code, dynamic theme options, options, option, wordpress theme options
Requires at least: 3.3
Tested up to: 4.3.1
Stable tag: trunk
License: GPLv2
License URI: http://www.gnu.org/licenses/gpl-2.0.html

This plugin will provide basic and dynamic functionality of theme options set in your admin panel 

so, you can easily change all the options any time.

== Description ==

Killer theme options plugin use for mainly basics option interface provided like Address, Copyright text, Tracking code, Social links (facebook, twitter, linkedin, google+) set in your admin panel. 

All above options is dynamic so, you can change easily from your admin panel.

That's it.
Enjoy.

== Installation ==

1. Upload the full directory into your wp-content/plugins directory
2. Activate the plugin at the plugin administration page
3. Open the plugin setting page, which is located under Appearance -> Killer Theme Options and 
customize settings.
4. The plugin will automatically update your Tracking code in footer.

and all other option you can get dynamically, so theres nothing more to do :)


== Frequently Asked Questions ==

= Where can I find the options page of the plugin? =

It is under Appearance > Killer Theme Options. I know nowadays many plugins add top-level menu 

items, but in most of the cases it is just not necessary

= Does this plugin work with all WordPress versions? =

This version works with WordPress 3.3 and grater version.


== Changelog ==
1.0 initial version
* added basic custom fields

2.0 Advanced functionality
* added basic custom fields and create unlimited custom fields as per user requirement

== Screenshots ==

1. General options ( screenshot-1.png )
2. Social setting ( screenshot-2.png )
3. Create new custom field ( screenshot-3.png )
4. view created new custom fields with it's value ( screenshot-4.png )

== License ==

Good news, this plugin is very useful for everyone who is develop custom wordpress theme! you can use it free of charge on your personal or commercial. blog.